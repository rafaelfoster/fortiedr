from pydantic import BaseModel, Field
from typing import Union, List

class IntOrListOfInt(BaseModel):
    value: Union[int, List[int]]

class Administrator:
    def __init__(self, conn):
        self.conn = conn

    def list_system_summary(self, organization: str = None):
        params = {
            'organization': organization
        }
        return self.conn.get("/management-rest/admin/list-system-summary", params=params)

    def upload_license(self, licenseBlob: bytes):
        return self.conn.upload("/management-rest/admin/upload-license", file={'licenseBlob': licenseBlob})
