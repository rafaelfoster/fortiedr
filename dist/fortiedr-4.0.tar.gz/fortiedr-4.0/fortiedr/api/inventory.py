from pydantic import BaseModel, Field
from typing import Union, List

class IntOrListOfInt(BaseModel):
    value: Union[int, List[int]]

class Inventory:
    def __init__(self, conn):
        self.conn = conn

    def get_collector_details(self, collectorId: str, organization: str = None):
        params = {
            'collectorId': collectorId,
            'organization': organization
        }
        return self.conn.get("/management-rest/inventory/get-collector-details", params=params)

    def list_collectors(self, organization: str = None):
        params = {
            'organization': organization
        }
        return self.conn.get("/management-rest/inventory/list-collectors", params=params)

    def list_groups(self, organization: str = None):
        params = {
            'organization': organization
        }
        return self.conn.get("/management-rest/inventory/list-groups", params=params)

    def move_collectors_to_group(self, collectorIds: Union[int, List[int]], groupId: int, organization: str = None):
        if isinstance(collectorIds, int):
            collectorIds = [collectorIds]
        params = {
            'collectorIds': collectorIds,
            'groupId': groupId,
            'organization': organization
        }
        return self.conn.send("/management-rest/inventory/move-collectors-to-group", params=params)

    def uninstall_collector(self, collectorId: str, organization: str = None):
        params = {
            'collectorId': collectorId,
            'organization': organization
        }
        return self.conn.send("/management-rest/inventory/uninstall-collector", params=params)
