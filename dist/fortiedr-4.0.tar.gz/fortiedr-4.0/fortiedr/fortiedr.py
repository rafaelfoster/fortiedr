import base64
import json
import logging
import requests
from datetime import datetime

from .api.administrator import Administrator
from .api.application_control import ApplicationControl
from .api.audit import Audit
from .api.av_scanner_file_controller import AVScannerFileController
from .api.communication_control import CommunicationControl
from .api.events import Events
from .api.exclusions import Exclusions
from .api.features import Features
from .api.forensic_analysis import ForensicAnalysis
from .api.forensics import Forensics
from .api.hash_search import HashSearch
from .api.incidents import Incidents
from .api.integrations_support import IntegrationsSupport
from .api.integrations import Integrations
from .api.inventory import Inventory
from .api.iot import IoT
from .api.ip_sets import IPSets
from .api.mobile import Mobile
from .api.organizations import Organizations
from .api.playbooks_policies import PlaybooksPolicies
from .api.policies import Policies
from .api.threat_hunting import ThreatHunting
from .api.users import Users

requests.packages.urllib3.disable_warnings()

class FortiEDR:
    def __init__(self, host, user, password, organization=None, enable_debug=False, enable_ssl=True):
        self.host = host
        self.user = user
        self.password = password
        self.organization = organization
        self.debug_enabled = enable_debug
        self.ssl_verify = enable_ssl
        self.headers = None
        self._auth()

        self.administrator = Administrator(self)
        self.application_control = ApplicationControl(self)
        self.audit = Audit(self)
        self.av_scanner_file_controller = AVScannerFileController(self)
        self.communication_control = CommunicationControl(self)
        self.events = Events(self)
        self.exclusions = Exclusions(self)
        self.features = Features(self)
        self.forensic_analysis = ForensicAnalysis(self)
        self.forensics = Forensics(self)
        self.hash_search = HashSearch(self)
        self.incidents = Incidents(self)
        self.integrations_support = IntegrationsSupport(self)
        self.integrations = Integrations(self)
        self.inventory = Inventory(self)
        self.iot = IoT(self)
        self.ip_sets = IPSets(self)
        self.mobile = Mobile(self)
        self.organizations = Organizations(self)
        self.playbooks_policies = PlaybooksPolicies(self)
        self.policies = Policies(self)
        self.threat_hunting = ThreatHunting(self)
        self.users = Users(self)

    def _auth(self):
        headers = {"Content-Type": "application/json"}
        auth_params = {
            "username": self.user,
            "password": self.password
        }
        
        response = self.send("/management-rest/login", auth_params)
        
        if response.get('status'):
            self.headers = {
                'X-XSRF-TOKEN': response['data']['token']
            }
            if self.organization:
                self.headers['organization'] = self.organization
        else:
            raise ConnectionError(f"Failed to authenticate: {response.get('data', {}).get('error_message', 'Unknown error')}")

    def enable_debug(self):
        import http.client as http_client
        http_client.HTTPConnection.debuglevel = 1

        logging.basicConfig()
        logger = logging.getLogger().setLevel(logging.DEBUG)
        requests_log = logging.getLogger("requests.packages.urllib3")
        requests_log.setLevel(logging.DEBUG)
        requests_log.propagate = True
        self.debug_enabled = True

    def get(self, url, params=None, request_type=None):
        return self._exec("GET", url, params, request_type=request_type)

    def send(self, url, params=None, request_type=None):
        return self._exec("POST", url, params, request_type=request_type)

    def insert(self, url, params=None, request_type=None):
        return self._exec("PUT", url, params, request_type=request_type)

    def update(self, url, params=None, request_type=None):
        return self._exec("PATCH", url, params, request_type=request_type)

    def delete(self, url, params=None, request_type=None):
        return self._exec("DELETE", url, params, request_type=request_type)
    
    def download(self, url, params=None, request_type=None, file_format = 'zip', download_folder = ''):
        self.download_folder = download_folder
        return self._exec("GET", url, params, request_type=request_type, download_file=True, file_format=file_format)
    
    def upload(self, url, file, params=None, request_type=None ):
        return self._exec("POST", url, params, request_type=request_type, upload_file=file)

    def _exec(self, method, url, params=None, download_file=False, request_type=None, file_format=None, upload_file=None):
        if method not in ['GET', 'POST', 'PUT', 'PATCH', 'DELETE']:
            raise ValueError("Method not supported")

        if not self.host:
            return "NOT AUTHENTICATED. Run Auth() first."

        params = {k: v for k, v in (params or {}).items() if v is not None}
        url = f"https://{self.host}{url}"

        if request_type:
            self.headers['Content-Type'] = request_type

        if self.debug_enabled:
            print("URL = ", url)
            print(json.dumps(self.headers, indent=4))
            print(json.dumps(params, indent=4))

        try:
            response = requests.request(
                method,
                url,
                headers=self.headers,
                json=params if method in ['POST', 'PUT', 'PATCH'] else None,
                params=params if method == 'GET' else None,
                verify=self.ssl_verify,
                stream=download_file,
                files=upload_file
            )
        except requests.exceptions.ConnectionError as e:
             return {
                'status': False,
                'data': {'status_code': 500, 'error_message': f'Failed to connect to {url}. Error: {e}'}
            }
        except requests.exceptions.RequestException as e:
            return {
                'status': False,
                'data': {'status_code': 500, 'error_message': e}
            }

        if not response.ok:
            try:
                error_message = response.json().get('errorMessage', response.text)
            except ValueError:
                error_message = response.text
            return {
                'status': False,
                'data': {'status_code': response.status_code, 'error_message': error_message}
            }

        if download_file:
            filename_function = url.split('/')[-1].replace('-','_')
            filename_function = filename_function.split('?')[0]
            if not self.download_folder:
                self.download_folder = '.'
            return self._handle_file_download(response, filename_function, file_format)

        try:
            return {'status': True, 'data': response.json()}
        except ValueError:  # If response is not JSON
            return {'status': True, 'data': response.text}

    def _handle_file_download(self, response, filename_prefix, file_format='zip'):
        date_now = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{self.download_folder}/{filename_prefix}_{date_now}.{file_format}"
        with open(filename, 'wb') as f:
            for chunk in response.iter_content(chunk_size=1024):
                f.write(chunk)
        return {'status': True, 'data': filename}